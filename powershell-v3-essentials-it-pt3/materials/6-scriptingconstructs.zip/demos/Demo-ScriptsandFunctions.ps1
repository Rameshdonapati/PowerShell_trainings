#requires -version 3.0

#region PowerShell Scripts

psedit s:\simplescript.ps1

#endregion

#region PowerShell functions

psedit S:\SimpleFunction.ps1

#endregion

Get-Verb